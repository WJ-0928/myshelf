﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace YF.DAL
{
    public class book
    {
        //增加
        public static bool addbook(YF.Model.book book)
        {

            bool result = false;

            string strsql = "insert into t_book (bookname,bookauthor,bookprice,booktype,bookissue) values ('" + book.Bookname + "','" + book.Bookauthor + "'," + book.Bookprice + ",'" + book.Booktype + "'," + book.Bookissue+ ")";

            int i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        //删除
        public static bool delbook(int bookid)
        {
            bool result = false;

            string strsql = "delete from t_book where bookid ='" + bookid + "'";

            int i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }

        //修改
        public static bool updatebook(YF.Model.book book)
        {
            bool result = false;

            string strsql = "update t_book set bookname='" + book.Bookname+ "',bookauthor='" + book.Bookauthor + "',bookprice=" + book.Bookprice + ",booktype='" + book.Booktype + "',bookissue=" + book.Bookissue+ "where bookid=" + book.Bookid + "";

            int i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        //通过id查看
        public static YF.Model.book Getbook(int bookid)
        {
            YF.Model.book book = new Model.book();

            string strsql = "select * from t_book where bookid=" + bookid + "";

            DataTable dataTable = YF.MsSqlHelper.YFMsSqlHelper.Query(strsql).Tables[0];
            if (dataTable.Rows.Count != 0)
            {
                book.Bookid = int.Parse(dataTable.Rows[0]["bookid"].ToString());
                book.Bookname = dataTable.Rows[0]["bookname"].ToString();
                book.Bookauthor = dataTable.Rows[0]["bookauthor"].ToString();
                book.Bookprice = int.Parse(dataTable.Rows[0]["bookprice"].ToString());
                book.Booktype = dataTable.Rows[0]["booktype"].ToString();
                book.Bookissue = int.Parse(dataTable.Rows[0]["bookissue"].ToString());
            }

            return book;
        }
        //查询所有
        public static List<YF.Model.book> List()
        {
            string strsql = "select * from t_book order by bookid asc";

            DataTable dataTable = YF.MsSqlHelper.YFMsSqlHelper.Query(strsql).Tables[0];
            return Dttolist(dataTable);
        }

        public static List<YF.Model.book> Dttolist(DataTable dataTable)
        {
            List<YF.Model.book> list = new List<Model.book>();

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                YF.Model.book book = new Model.book();
                book.Bookid = int.Parse(dataTable.Rows[i]["bookid"].ToString());
                book.Bookname = dataTable.Rows[i]["bookname"].ToString();
                book.Bookauthor = dataTable.Rows[i]["bookauthor"].ToString();
                book.Bookprice = int.Parse(dataTable.Rows[i]["bookprice"].ToString());
                book.Booktype = dataTable.Rows[i]["booktype"].ToString();
                book.Bookissue = int.Parse(dataTable.Rows[i]["bookissue"].ToString());
                list.Add(book);
            }

            return list;
        }
    }
}
