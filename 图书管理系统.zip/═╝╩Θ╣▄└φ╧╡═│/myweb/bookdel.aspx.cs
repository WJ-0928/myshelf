﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class bookdel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
            YF.Model.book book = new YF.Model.book();
            if (this.bookid.Text != null)
            {
                YF.BLL.book.delbook(int.Parse(this.bookid.Text));
                YF.JsHelper.AlertAndRedirect("删除成功!", "admin.aspx");
            }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        YF.JsHelper.Redirect("admin.aspx");
    }
}