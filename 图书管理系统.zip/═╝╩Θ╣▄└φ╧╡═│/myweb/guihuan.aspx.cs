﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class guihuan : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        YF.Model.borrow bor = new YF.Model.borrow();
        if (YF.BLL.borrow.delbor(int.Parse(this.isbookid.Text)) == true)
        {
            if (YF.BLL.borrow.updatebor1(int.Parse(this.isbookid.Text)) == true)
            {
                YF.JsHelper.AlertAndRedirect("归还成功！", "User.aspx");
            }
            
        }
        else
        {
            YF.JsHelper.AlertAndRedirect("归还失败！", "guihuan.aspx");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        YF.JsHelper.Redirect("borrowim.aspx");
    }
}