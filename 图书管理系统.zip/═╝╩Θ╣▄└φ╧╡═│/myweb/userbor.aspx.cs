﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class userbor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (!IsPostBack)
        //{
        //    YF.Model.borrow bor = new YF.Model.borrow();
        //    bor.Isbookid = int.Parse(this.isbookid.Text);
        //    bor.Isbookname = this.isbookname.Text;
        //    bor.Isname = this.isname.Text;
        //    bor.Isid = int.Parse(this.isid.Text);
        //    bor.Isdate = DateTime.Parse(this.isdate.Text);
        //}
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        YF.Model.book book = new YF.Model.book();
        YF.Model.borrow bor = new YF.Model.borrow();
        bor.Isbookid = int.Parse(this.isbookid.Text);
        bor.Isbookname = this.isbookname.Text;
        bor.Isname = this.isname.Text;
        bor.Isid = int.Parse(this.isid.Text);
        bor.Isdate = DateTime.Now;
        if (book.Bookissue == 0)
        {

            if (YF.BLL.borrow.addbor(bor) == true)
            {
                if (YF.BLL.borrow.updatebor2(int.Parse(this.isbookid.Text)) == true)
                {
                    YF.JsHelper.AlertAndRedirect("借阅成功！", "User.aspx");
                }

            }
            else
            {
                YF.JsHelper.AlertAndRedirect("借阅失败！", "userbor.aspx");
            }
        }
        else
        {
            YF.JsHelper.AlertAndRedirect("不可借阅", "userbookim");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        YF.JsHelper.Redirect("userbookim.aspx");
    }
}