﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace YF.DAL
{
    public class borrow
    {
        public static List<YF.Model.borrow> list(int isid)
        {
            string strsql = "select * from t_iss where isid=" + isid + "order by isdate desc";
            DataTable dt = YF.MsSqlHelper.YFMsSqlHelper.Query(strsql).Tables[0];
            return Dotolist(dt);
        }
        public static List<YF.Model.borrow> list()
        {
            string strsql = "select * from t_iss order by isdate desc";
            DataTable dt = YF.MsSqlHelper.YFMsSqlHelper.Query(strsql).Tables[0];
            return Dotolist(dt);
        }
        public static List<YF.Model.borrow> Dotolist(DataTable dt)
        {
            List<YF.Model.borrow> list = new List<Model.borrow>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                YF.Model.borrow bor = new Model.borrow();
                bor.Isid = int.Parse(dt.Rows[i]["isid"].ToString());
                bor.Isname = dt.Rows[i]["isname"].ToString();
                bor.Isbookid = int.Parse(dt.Rows[i]["isbookid"].ToString());
                bor.Isbookname = dt.Rows[i]["isbookname"].ToString();
                bor.Isdate = DateTime.Parse(dt.Rows[i]["isdate"].ToString());
                list.Add(bor);
            }
            return list;
        }

        //guihuan
        public static bool updatebor1(int isbookid)
        {
            bool result = false;
            string strsql = "update t_book set bookissue='0'where bookid='" + isbookid + "'";
            int i = 0;
            i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        public static bool updatebor2(int isbookid)
        {
            bool result = false;
            string strsql = "update t_book set bookissue='1' where bookid='" + isbookid + "'";
            int i = 0;
            i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        //修改
        public static bool update(YF.Model.borrow bor)
        {
            bool result = false;

            string strsql = "update t_iss set isbookid=" + bor.Isbookid + ",isbookname='" + bor.Isbookname + "',isname=" + bor.Isname + ",isid=" + bor.Isid + ",isdate='" + bor.Isdate + "'";

            int i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        public static bool addbor(YF.Model.borrow bor)
        {
            bool result = false;
            string strsql = "insert into t_iss(isbookid,isbookname,isname,isid,isdate) values(" + bor.Isbookid+ ",'" + bor.Isbookname + "','" + bor.Isname + "'," + bor.Isid + ",'" + bor.Isdate + "')";
            int i = 0;
            i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }

        //删除
        public static bool delbor(int isbookid)
        {
            bool result = false;

            string strsql = "delete from t_iss where isbookid =" + isbookid + "";

            int i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
    }
}
