﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YF.BLL
{
    public class book
    {
        public static bool addbook(YF.Model.book book)
        {
            return YF.DAL.book.addbook(book);
        }
        public static bool delbook(int bookid)
        {
            return YF.DAL.book.delbook(bookid);
        }
        public static bool updatebook(YF.Model.book book) 
        {
            return YF.DAL.book.updatebook(book);
        }
        public static YF.Model.book Getbook(int bookid) 
        {
            return YF.DAL.book.Getbook(bookid);
        }
        public static List<YF.Model.book> List() 
        {
            return YF.DAL.book.List();
        }
    }
}
