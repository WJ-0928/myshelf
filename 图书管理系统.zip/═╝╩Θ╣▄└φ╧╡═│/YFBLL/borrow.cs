﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YF.BLL
{
    public class borrow
    {
        public static bool updatebor1(int isbookid)
        {
            return YF.DAL.borrow.updatebor1(isbookid);
        }
        public static bool updatebor2(int isbookid)
        {
            return YF.DAL.borrow.updatebor2(isbookid);
        }
        public static bool addbor(YF.Model.borrow bor)
        {
            return YF.DAL.borrow.addbor(bor);
        }
        public static bool delbor(int isbookid)
        {
            return YF.DAL.borrow.delbor(isbookid);
        }
        public static List<YF.Model.borrow> list()
        {
            return YF.DAL.borrow.list();
        }
        public static bool update(YF.Model.borrow bor)
        {
            return YF.DAL.borrow.update(bor);
        }

    }
}
